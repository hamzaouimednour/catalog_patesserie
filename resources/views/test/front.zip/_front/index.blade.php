<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Takacim - Bienvenue chez nous</title>
        <!-- All CSS Files -->
        <!-- Theme main style -->
        <link rel="stylesheet" href="{{ asset('static/main.css') }}">
    </head>
    <body onclick="location.href='/home'">
        <div class="bg"></div>
    </body>
</html>
